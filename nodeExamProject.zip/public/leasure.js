var socket = io.connect("http://localhost:500");

// when page is opened it makes a call to the db to retrive all leasure bikes etc.

socket.emit("retrive_leasure", {"message":"retrive_leasure"});

var test = {};

// getting bikes back from the database
socket.on("leasure_bikes_from_db", function(jData){
  // putting all of the leasure bikes into a dynamically allocated div's
    console.log(jData.length);
    test = jData;
    for(let i = 0 ; i < jData.length; i++){
      var link = "leasureBike";
      $("#leasureBikesDiv").append("<a><h1 id="+jData[i].modelName+" >"+jData[i].modelName+"</h1></a>");
    }
});

// displaying a certain bike when clicked on
$(function() {
$(document).on("click", 'a', function(event) {
  // using function and then 'on' instead of 'click' cause 'click' only works for
  // elements written in the original html doc not the ones dynamically added

  var clickedBike = event.target.id;
  // cross matching a chosen bike with the one in the database
  // for(let i = 0 ; i < test.length; i++){
  //   if(test[i].modelName == clickedBike){
  //     console.log("The bike exists in the data base and is: "+clickedBike);
  //     populateLeasureBikeLabels(test[i]);
  //     break;
  //   }
  //   else {
  //     console.log("The bike doesnt exist in the database");
  //   }
  // }

  // making a ajax call to the server
			var sUrl = "leasureBike/"+clickedBike;
			$.getJSON( sUrl , function( jData ){
				console.log("Bike has been sent successfuly");
			});
  });
});

function populateLeasureBikeLabels(bikeArray){
  // console.log("Hi from the method: "+bikeArray.modelName);

  // populating the site with the bike info
  $("#modelNameLabel").append("jajaj");
}
